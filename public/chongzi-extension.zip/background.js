// Background Service Worker for ChongZi Chrome Extension
const DEFAULT_SERVER_URL = 'http://localhost:3000';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "add_to_chongzi",
    title: "Dịch & Lưu vào ChongZi",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "add_to_chongzi" && info.selectionText) {
    // Send selected text to content script on active tab
    chrome.tabs.sendMessage(tab.id, {
      action: "context_menu_search",
      text: info.selectionText
    });
  }
});

// Helper to get configuration
async function getConfig() {
  const result = await chrome.storage.local.get(['serverUrl', 'token', 'user']);
  return {
    serverUrl: result.serverUrl || DEFAULT_SERVER_URL,
    token: result.token || '',
    user: result.user ? JSON.parse(result.user) : null
  };
}

// Handle messaging from popup and content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "get_config") {
    getConfig().then(sendResponse);
    return true; // async response
  }

  if (request.action === "save_config") {
    chrome.storage.local.set({
      serverUrl: request.serverUrl,
      token: request.token,
      user: request.user ? JSON.stringify(request.user) : null
    }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === "sync_token_from_tab") {
    // Search for a tab running the ChongZi application
    chrome.tabs.query({}, (tabs) => {
      let targetTab = null;
      for (const tab of tabs) {
        if (tab.url && (tab.url.includes('chongziapp.id.vn') || tab.url.includes('localhost:5173'))) {
          targetTab = tab;
          break;
        }
      }

      if (!targetTab) {
        sendResponse({ success: false, error: "Không tìm thấy tab ứng dụng ChongZi nào đang chạy. Vui lòng đăng nhập vào ứng dụng web trước!" });
        return;
      }

      // Execute script in that tab to retrieve credentials from localStorage
      chrome.scripting.executeScript({
        target: { tabId: targetTab.id },
        func: () => {
          return {
            token: localStorage.getItem('token'),
            user: localStorage.getItem('user'),
            serverUrl: window.location.origin.includes('chongziapp.id.vn') 
              ? 'https://chongziapp.id.vn' 
              : 'http://localhost:3000'
          };
        }
      }, (results) => {
        if (chrome.runtime.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
          return;
        }

        if (results && results[0] && results[0].result) {
          const res = results[0].result;
          if (res.token) {
            let parsedUser = null;
            try { parsedUser = JSON.parse(res.user); } catch (e) {}

            chrome.storage.local.set({
              token: res.token,
              user: res.user,
              serverUrl: res.serverUrl
            }).then(() => {
              sendResponse({
                success: true,
                token: res.token,
                user: parsedUser,
                serverUrl: res.serverUrl
              });
            });
          } else {
            sendResponse({ success: false, error: "Bạn chưa đăng nhập trên tab ứng dụng ChongZi. Vui lòng đăng nhập!" });
          }
        } else {
          sendResponse({ success: false, error: "Không thể lấy thông tin đăng nhập từ tab ứng dụng." });
        }
      });
    });
    return true; // async response
  }

  if (request.action === "search_dictionary") {
    getConfig().then(config => {
      const url = `${config.serverUrl}/api/dictionary/search?q=${encodeURIComponent(request.text)}`;
      fetch(url)
        .then(res => {
          if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
          return res.json();
        })
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
    });
    return true; // async
  }

  if (request.action === "get_decks") {
    getConfig().then(config => {
      if (!config.token) {
        sendResponse({ success: false, error: "Chưa đăng nhập. Vui lòng đồng bộ thông tin đăng nhập trong Popup tiện ích!" });
        return;
      }
      const url = `${config.serverUrl}/api/decks`;
      fetch(url, {
        headers: {
          'Authorization': `Bearer ${config.token}`
        }
      })
        .then(res => {
          if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
          return res.json();
        })
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
    });
    return true; // async
  }

  if (request.action === "save_flashcard") {
    getConfig().then(config => {
      if (!config.token) {
        sendResponse({ success: false, error: "Chưa đăng nhập. Vui lòng đồng bộ thông tin đăng nhập trong Popup tiện ích!" });
        return;
      }
      const url = `${config.serverUrl}/api/flashcards`;
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.token}`
        },
        body: JSON.stringify(request.cardData)
      })
        .then(res => {
          if (!res.ok) return res.json().then(e => { throw new Error(e.message || `Lưu lỗi: ${res.status}`); });
          return res.json();
        })
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
    });
    return true; // async
  }
});
