// Content Script for ChongZi Chrome Extension

let activeBubble = null;
let activeModal = null;
let currentSelectionText = '';

// Check selection change
document.addEventListener('mouseup', handleMouseUp);
document.addEventListener('mousedown', handleMouseDown);

// Listen to context menu trigger
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "context_menu_search" && request.text) {
    showTranslationModal(request.text.trim());
    sendResponse({ success: true });
  }
});

function handleMouseDown(e) {
  // If click outside bubble, remove bubble
  if (activeBubble && !activeBubble.contains(e.target)) {
    removeBubble();
  }
}

function handleMouseUp(e) {
  const host = document.getElementById('chongzi-modal-host');
  if (host && (host === e.target || host.contains(e.target))) {
    return;
  }

  const selection = window.getSelection();
  const text = selection.toString().trim();

  if (!text || text.length > 30) {
    return;
  }
  
  // Basic filter: only trigger if contains Chinese characters or is a single word
  const containsChinese = /[\u4e00-\u9fa5]/.test(text);
  const isWord = /^[a-zA-Z\s\-']{2,25}$/.test(text); // Basic English word check
  
  if (!containsChinese && !isWord) {
    return;
  }

  currentSelectionText = text;
  
  // Show bubble near selection
  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();
  
  showBubble(rect.left + window.scrollX + (rect.width / 2), rect.top + window.scrollY - 30);
}

function showBubble(x, y) {
  removeBubble();
  
  const bubble = document.createElement('div');
  bubble.id = 'chongzi-ext-bubble';
  bubble.style.position = 'absolute';
  bubble.style.left = `${x - 14}px`;
  bubble.style.top = `${y}px`;
  bubble.style.zIndex = '999999999';
  bubble.style.width = '28px';
  bubble.style.height = '28px';
  bubble.style.borderRadius = '50%';
  bubble.style.backgroundColor = '#14b8a6'; // Teal brand color
  bubble.style.border = '2px solid white';
  bubble.style.boxShadow = '0 4px 10px rgba(0,0,0,0.15)';
  bubble.style.cursor = 'pointer';
  bubble.style.display = 'flex';
  bubble.style.alignItems = 'center';
  bubble.style.justifyContent = 'center';
  bubble.style.transition = 'transform 0.15s ease-out';
  bubble.style.userSelect = 'none';
  
  // C Logo text
  bubble.innerHTML = `<span style="color: white; font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 900; line-height: 1;">蝨</span>`;
  
  bubble.addEventListener('mouseenter', () => {
    bubble.style.transform = 'scale(1.12)';
  });
  bubble.addEventListener('mouseleave', () => {
    bubble.style.transform = 'scale(1)';
  });
  
  bubble.addEventListener('click', (e) => {
    e.stopPropagation();
    showTranslationModal(currentSelectionText);
    removeBubble();
  });
  
  document.body.appendChild(bubble);
  activeBubble = bubble;
}

function removeBubble() {
  if (activeBubble) {
    activeBubble.remove();
    activeBubble = null;
  }
}

function removeModal() {
  if (activeModal) {
    activeModal.remove();
    activeModal = null;
  }
}

function showTranslationModal(text) {
  removeModal();
  
  // Create Shadow DOM host
  const host = document.createElement('div');
  host.id = 'chongzi-modal-host';
  host.style.position = 'fixed';
  host.style.bottom = '20px';
  host.style.right = '20px';
  host.style.zIndex = '9999999999';
  host.style.fontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
  
  const shadow = host.attachShadow({ mode: 'open' });
  document.body.appendChild(host);
  activeModal = host;
  
  // Style in Shadow DOM
  const style = document.createElement('style');
  style.textContent = `
    .panel {
      width: 320px;
      background: rgba(255, 255, 255, 0.95);
      border: 1px solid rgba(20, 184, 166, 0.2);
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.15);
      padding: 16px;
      backdrop-filter: blur(10px);
      box-sizing: border-box;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      transform: translateY(0);
      opacity: 1;
      color: #1e293b;
    }
    
    .dark-mode {
      background: rgba(24, 24, 27, 0.96);
      border-color: rgba(20, 184, 166, 0.3);
      color: #f4f4f5;
    }
    
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-b: 1px solid rgba(0, 0, 0, 0.05);
      margin-bottom: 12px;
      padding-bottom: 8px;
    }
    
    .title {
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: #14b8a6;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .close-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 18px;
      color: #94a3b8;
      padding: 2px 6px;
      line-height: 1;
      border-radius: 4px;
    }
    .close-btn:hover {
      background: rgba(0, 0, 0, 0.05);
      color: #475569;
    }
    
    .loader {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px 0;
      color: #64748b;
      font-size: 13px;
      gap: 8px;
    }
    
    .spinner {
      width: 24px;
      height: 24px;
      border: 3px solid rgba(20, 184, 166, 0.1);
      border-top-color: #14b8a6;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    
    .word-title {
      font-size: 32px;
      font-weight: 800;
      color: #0f172a;
      margin-bottom: 2px;
    }
    .dark-mode .word-title {
      color: #ffffff;
    }
    
    .pinyin {
      font-size: 15px;
      font-weight: 600;
      color: #14b8a6;
      font-family: monospace;
      margin-bottom: 10px;
    }
    
    .translation-box {
      background: rgba(0, 0, 0, 0.02);
      border: 1px solid rgba(0, 0, 0, 0.06);
      border-radius: 8px;
      padding: 10px;
      margin-bottom: 12px;
      font-size: 13px;
      line-height: 1.5;
      max-height: 120px;
      overflow-y: auto;
    }
    .dark-mode .translation-box {
      background: rgba(255, 255, 255, 0.03);
      border-color: rgba(255, 255, 255, 0.08);
    }
    
    .form-group {
      margin-bottom: 12px;
    }
    
    .label {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      color: #64748b;
      margin-bottom: 4px;
      display: block;
    }
    
    .select, .input {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      font-size: 13px;
      outline: none;
      box-sizing: border-box;
      background: white;
      color: #1e293b;
    }
    .dark-mode .select, .dark-mode .input {
      background: #27272a;
      border-color: #3f3f46;
      color: #f4f4f5;
    }
    
    .select:focus, .input:focus {
      border-color: #14b8a6;
    }
    
    .btn {
      width: 100%;
      background: #14b8a6;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 10px;
      font-weight: 700;
      font-size: 13px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: background 0.15s;
    }
    .btn:hover {
      background: #0d9488;
    }
    .btn:disabled {
      background: #94a3b8;
      cursor: not-allowed;
    }
    
    .success-panel {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px 0;
      text-align: center;
    }
    
    .checkmark {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #ccfbf1;
      color: #14b8a6;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 12px;
      animation: pop 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    
    @keyframes pop {
      0% { transform: scale(0.6); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }
    
    .error-msg {
      color: #ef4444;
      font-size: 12px;
      margin-bottom: 8px;
      font-weight: 600;
    }
  `;
  shadow.appendChild(style);
  
  // Render structure
  const isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  const panel = document.createElement('div');
  panel.className = `panel ${isDark ? 'dark-mode' : ''}`;
  panel.innerHTML = `
    <div class="header">
      <div class="title">
        <span style="font-size: 14px;">蝨</span> ChongZi Translation
      </div>
      <button class="close-btn">&times;</button>
    </div>
    <div class="content-body">
      <div class="loader">
        <div class="spinner"></div>
        Đang tra cứu từ điển...
      </div>
    </div>
  `;
  
  shadow.appendChild(panel);
  
  panel.querySelector('.close-btn').addEventListener('click', removeModal);
  
  // Fetch dictionary translation via background
  chrome.runtime.sendMessage({
    action: "search_dictionary",
    text: text
  }, (response) => {
    if (!response || !response.success) {
      showError(panel, response?.error || "Không thể kết nối đến máy chủ ChongZi.");
      return;
    }
    
    const results = response.data;
    const entry = results[0] || {
      word: text,
      pinyin: '',
      definition: 'Không tìm thấy định nghĩa trong từ điển.'
    };
    
    // Fetch decks via background
    chrome.runtime.sendMessage({ action: "get_decks" }, (decksResponse) => {
      let decks = [];
      let authError = '';
      
      if (decksResponse && decksResponse.success) {
        decks = decksResponse.data || [];
      } else {
        authError = decksResponse?.error || "Vui lòng đồng bộ đăng nhập trong extension popup.";
      }
      
      renderTranslator(panel, entry, decks, authError);
    });
  });
}

function showError(panel, errorText) {
  const body = panel.querySelector('.content-body');
  body.innerHTML = `
    <div style="padding: 10px 0; text-align: center;">
      <div class="error-msg">${errorText}</div>
      <button class="btn" style="background:#475569; margin-top:8px;" id="retry-close">Đóng</button>
    </div>
  `;
  body.querySelector('#retry-close').addEventListener('click', removeModal);
}

function renderTranslator(panel, entry, decks, authError) {
  const body = panel.querySelector('.content-body');
  
  let deckOptions = '';
  if (decks.length > 0) {
    deckOptions = decks.map(d => `<option value="${d.id}">${d.title || d.name} (${d.language === 'EN' ? 'Tiếng Anh' : 'Tiếng Trung'})</option>`).join('');
  } else {
    deckOptions = `<option value="">-- Không tìm thấy bộ bài --</option>`;
  }
  
  body.innerHTML = `
    <div class="word-title">${entry.word}</div>
    <div class="pinyin">${entry.pinyin || ''}</div>
    
    <div class="translation-box">
      ${entry.definition || entry.meaning || 'Chưa có giải nghĩa.'}
    </div>
    
    ${authError ? `<div class="error-msg" style="font-size:11px; line-height:1.4;">⚠️ ${authError}</div>` : ''}
    
    <div class="form-group">
      <span class="label">Chọn bộ bài lưu trữ</span>
      <select class="select" id="target-deck" ${authError ? 'disabled' : ''}>
        ${deckOptions}
      </select>
    </div>
    
    <div class="form-group">
      <span class="label">Nghĩa thẻ bài (Có thể chỉnh sửa)</span>
      <input type="text" class="input" id="card-meaning" value="${entry.definition || entry.meaning || ''}" ${authError ? 'disabled' : ''}>
    </div>
    
    <button class="btn" id="save-card-btn" ${authError || decks.length === 0 ? 'disabled' : ''}>
      💾 Lưu vào ChongZi
    </button>
  `;
  
  if (authError || decks.length === 0) return;
  
  const saveBtn = body.querySelector('#save-card-btn');
  saveBtn.addEventListener('click', () => {
    const deckId = Number(body.querySelector('#target-deck').value);
    const meaning = body.querySelector('#card-meaning').value.trim();
    
    if (!deckId) return;
    
    saveBtn.disabled = true;
    saveBtn.textContent = 'Đang lưu...';
    
    const cardData = {
      deckId: deckId,
      hanzi: entry.word,
      pinyin: entry.pinyin || '',
      meaning: meaning || 'Chưa có giải nghĩa.'
    };
    
    chrome.runtime.sendMessage({
      action: "save_flashcard",
      cardData: cardData
    }, (saveResponse) => {
      if (saveResponse && saveResponse.success) {
        renderSuccess(panel);
      } else {
        saveBtn.disabled = false;
        saveBtn.textContent = '💾 Thử lại';
        alert(saveResponse?.error || "Có lỗi xảy ra khi lưu thẻ.");
      }
    });
  });
}

function renderSuccess(panel) {
  const body = panel.querySelector('.content-body');
  body.innerHTML = `
    <div class="success-panel">
      <div class="checkmark">✓</div>
      <div style="font-weight: 700; font-size: 15px; color: #0f172a; margin-bottom: 4px;">Đã lưu thẻ thành công!</div>
      <div style="font-size: 12px; color: #64748b; margin-bottom: 16px;">Từ vựng này đã được thêm vào bộ bài của bạn.</div>
      <button class="btn" style="width:auto; padding: 8px 24px;" id="success-done-btn">Xong</button>
    </div>
  `;
  
  body.querySelector('#success-done-btn').addEventListener('click', removeModal);
  
  // Auto-remove modal after 2.5s
  setTimeout(removeModal, 2500);
}
