// Popup script for ChongZi Chrome Extension

document.addEventListener('DOMContentLoaded', () => {
  const stateConnected = document.getElementById('state-connected');
  const stateDisconnected = document.getElementById('state-disconnected');
  const errorContainer = document.getElementById('error-container');
  
  // Element declarations
  const syncBtn = document.getElementById('sync-btn');
  const disconnectBtn = document.getElementById('disconnect-btn');
  const saveServerBtn = document.getElementById('save-server-btn');
  const serverUrlInput = document.getElementById('server-url-input');
  const activeServerUrl = document.getElementById('active-server-url');
  
  const userName = document.getElementById('user-name');
  const userRole = document.getElementById('user-role');
  const userAvatar = document.getElementById('user-avatar');
  const openWebLink = document.getElementById('open-web-link');

  // Load and apply configurations on open
  updateUI();

  // Sync token from tab button
  syncBtn.addEventListener('click', () => {
    showError('');
    syncBtn.disabled = true;
    syncBtn.textContent = 'Đang quét tab ứng dụng...';
    
    chrome.runtime.sendMessage({ action: "sync_token_from_tab" }, (response) => {
      syncBtn.disabled = false;
      syncBtn.textContent = '🔗 Đồng bộ Đăng nhập từ Tab';
      
      if (response && response.success) {
        updateUI();
      } else {
        showError(response?.error || "Đồng bộ thất bại. Đảm bảo tab ChongZi đang mở và bạn đã đăng nhập.");
      }
    });
  });

  // Disconnect button
  disconnectBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({
      action: "save_config",
      serverUrl: serverUrlInput.value,
      token: '',
      user: null
    }, () => {
      updateUI();
    });
  });

  // Save server URL button
  saveServerBtn.addEventListener('click', () => {
    let url = serverUrlInput.value.trim();
    if (url.endsWith('/')) {
      url = url.slice(0, -1);
    }
    
    chrome.runtime.sendMessage({
      action: "get_config"
    }, (config) => {
      chrome.runtime.sendMessage({
        action: "save_config",
        serverUrl: url,
        token: config.token,
        user: config.user
      }, () => {
        alert('Đã lưu địa chỉ máy chủ!');
      });
    });
  });

  // Link to open web dashboard
  openWebLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.sendMessage({ action: "get_config" }, (config) => {
      let url = 'http://localhost:5173';
      if (config.serverUrl.includes('chongziapp.id.vn') || config.serverUrl.includes('3000')) {
        url = config.serverUrl.replace(':3000', ':5173');
      }
      chrome.tabs.create({ url });
    });
  });

  // Update UI based on saved configuration
  function updateUI() {
    chrome.runtime.sendMessage({ action: "get_config" }, (config) => {
      serverUrlInput.value = config.serverUrl;
      activeServerUrl.value = config.serverUrl;

      if (config.token) {
        // Attempt to fetch profile to verify token validity
        const profileUrl = `${config.serverUrl}/api/users/me`;
        fetch(profileUrl, {
          headers: {
            'Authorization': `Bearer ${config.token}`
          }
        })
          .then(res => {
            if (!res.ok) throw new Error("Token expired or invalid");
            return res.json();
          })
          .then(userData => {
            // Render user details
            userName.textContent = userData.fullName || userData.username || 'Người dùng';
            userRole.textContent = userData.role === 'admin' ? 'Quản trị viên' : 'Học viên';
            userAvatar.textContent = (userData.fullName || userData.username || 'U').substring(0, 1).toUpperCase();
            
            // Show connected state
            stateConnected.style.display = 'block';
            stateDisconnected.style.display = 'none';
          })
          .catch(err => {
            console.warn("Session verification failed, logging out:", err);
            // Session expired, clear token
            chrome.runtime.sendMessage({
              action: "save_config",
              serverUrl: config.serverUrl,
              token: '',
              user: null
            }, () => {
              stateConnected.style.display = 'none';
              stateDisconnected.style.display = 'block';
            });
          });
      } else {
        stateConnected.style.display = 'none';
        stateDisconnected.style.display = 'block';
      }
    });
  }

  // Display error messages
  function showError(msg) {
    if (msg) {
      errorContainer.textContent = msg;
      errorContainer.style.display = 'block';
    } else {
      errorContainer.style.display = 'none';
    }
  }
});
